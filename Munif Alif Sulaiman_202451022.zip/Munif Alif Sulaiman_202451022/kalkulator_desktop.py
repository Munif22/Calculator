import tkinter as tk
from tkinter import messagebox


class KalkulatorDesktop:
    def __init__(self, root):
        self.root = root
        self.root.title("Kalkulator Desktop")
        self.root.geometry("360x500")
        self.root.resizable(False, False)
        self.root.configure(bg="#1e1e1e")

        # Variabel untuk menyimpan ekspresi
        self.expression = ""
        self.input_text = tk.StringVar()

        # Membuat komponen GUI
        self.create_display()
        self.create_buttons()

        # Binding keyboard (opsional, agar bisa pakai keyboard juga)
        self.root.bind("<Key>", self.key_press)
        self.root.bind("<Return>", lambda e: self.hitung())
        self.root.bind("<BackSpace>", lambda e: self.hapus())
        self.root.bind("<Escape>", lambda e: self.clear())

    def create_display(self):
        """Membuat layar tampilan kalkulator"""
        display_frame = tk.Frame(self.root, bg="#1e1e1e")
        display_frame.pack(fill="both", padx=10, pady=(20, 10))

        display = tk.Entry(
            display_frame,
            textvariable=self.input_text,
            font=("Segoe UI", 28, "bold"),
            bg="#2d2d2d",
            fg="#ffffff",
            bd=0,
            justify="right",
            insertbackground="#ffffff",
        )
        display.pack(fill="both", ipady=20)

    def create_buttons(self):
        """Membuat tombol-tombol kalkulator"""
        button_frame = tk.Frame(self.root, bg="#1e1e1e")
        button_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Layout tombol (baris x kolom)
        buttons = [
            ["C", "⌫", "%", "/"],
            ["7", "8", "9", "*"],
            ["4", "5", "6", "-"],
            ["1", "2", "3", "+"],
            ["±", "0", ".", "="],
        ]

        # Warna tombol
        color_number = "#3a3a3a"
        color_operator = "#ff9500"
        color_function = "#505050"
        color_equal = "#28a745"

        for i, row in enumerate(buttons):
            button_frame.rowconfigure(i, weight=1)
            for j, label in enumerate(row):
                button_frame.columnconfigure(j, weight=1)

                # Tentukan warna berdasarkan label
                if label in ["/", "*", "-", "+"]:
                    bg_color = color_operator
                elif label in ["C", "⌫", "%", "±"]:
                    bg_color = color_function
                elif label == "=":
                    bg_color = color_equal
                else:
                    bg_color = color_number

                btn = tk.Button(
                    button_frame,
                    text=label,
                    font=("Segoe UI", 16, "bold"),
                    bg=bg_color,
                    fg="#ffffff",
                    bd=0,
                    activebackground="#666666",
                    activeforeground="#ffffff",
                    command=lambda l=label: self.on_button_click(l),
                    cursor="hand2",
                )
                btn.grid(row=i, column=j, sticky="nsew", padx=4, pady=4)

    def on_button_click(self, label):
        """Menangani klik tombol"""
        if label == "C":
            self.clear()
        elif label == "⌫":
            self.hapus()
        elif label == "=":
            self.hitung()
        elif label == "±":
            self.toggle_sign()
        elif label == "%":
            self.persen()
        else:
            self.expression += label
            self.input_text.set(self.expression)

    def clear(self):
        """Menghapus semua isi"""
        self.expression = ""
        self.input_text.set("")

    def hapus(self):
        """Menghapus satu karakter terakhir"""
        self.expression = self.expression[:-1]
        self.input_text.set(self.expression)

    def toggle_sign(self):
        """Mengubah tanda positif/negatif"""
        if self.expression:
            try:
                if self.expression.startswith("-"):
                    self.expression = self.expression[1:]
                else:
                    self.expression = "-" + self.expression
                self.input_text.set(self.expression)
            except Exception:
                pass

    def persen(self):
        """Mengkonversi ke persen (dibagi 100)"""
        try:
            if self.expression:
                hasil = float(eval(self.expression)) / 100
                self.expression = str(hasil)
                self.input_text.set(self.expression)
        except Exception:
            messagebox.showerror("Error", "Ekspresi tidak valid")
            self.clear()

    def hitung(self):
        """Melakukan perhitungan matematika"""
        if not self.expression:
            return
        try:
            # Ganti simbol agar aman dievaluasi
            expr = self.expression.replace("×", "*").replace("÷", "/")
            hasil = eval(expr, {"__builtins__": None}, {})
            # Tampilkan hasil
            self.expression = str(hasil)
            self.input_text.set(self.expression)
        except ZeroDivisionError:
            messagebox.showerror("Error", "Tidak bisa dibagi nol")
            self.clear()
        except Exception:
            messagebox.showerror("Error", "Ekspresi tidak valid")
            self.clear()

    def key_press(self, event):
        """Menangani input dari keyboard"""
        char = event.char
        if char in "0123456789+-*/.%":
            self.expression += char
            self.input_text.set(self.expression)


def main():
    root = tk.Tk()
    app = KalkulatorDesktop(root)
    root.mainloop()


if __name__ == "__main__":
    main()